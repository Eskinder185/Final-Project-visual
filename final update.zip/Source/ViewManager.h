///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"


// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
    // Constructor
    ViewManager(ShaderManager* pShaderManager);
    // Destructor
    ~ViewManager();

    // Mouse position callback for interaction with the 3D scene
    static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

    // Create the initial OpenGL display window
    GLFWwindow* CreateDisplayWindow(const char* windowTitle);

    // Prepare the conversion from 3D object display to 2D scene display
    void PrepareSceneView();

    // Process keyboard events for interaction with the 3D scene
    void ProcessKeyboardEvents();

    // Update the camera's view and projection matrices
    void UpdateViewAndProjectionMatrices();

    // Update delta time for frame-independent movement
    void UpdateDeltaTime();

    // Set camera movement speed
    void SetCameraSpeed(float speed);

private:
    // Pointer to shader manager object
    ShaderManager* m_pShaderManager;

    // Active OpenGL display window
    GLFWwindow* m_pWindow;

    // Camera properties
    glm::vec3 m_cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);  // Camera position
    glm::vec3 m_cameraFront = glm::vec3(0.0f, 0.0f, -1.0f); // Camera front direction
    glm::vec3 m_cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);   // Camera up vector
    float m_cameraYaw = -90.0f; // Horizontal rotation
    float m_cameraPitch = 0.0f; // Vertical rotation
    float m_cameraSpeed = 2.5f; // Movement speed
    float m_deltaTime = 0.0f;   // Time between frames
    float m_lastFrame = 0.0f;   // Time of last frame

    // Mouse input tracking
    bool m_firstMouse = true;
    float m_lastX = 400.0f; // Center of the screen (x-axis)
    float m_lastY = 300.0f; // Center of the screen (y-axis)
    float m_sensitivity = 0.1f; // Mouse sensitivity

    // Update the camera direction based on yaw and pitch
    void UpdateCameraDirection();
};
